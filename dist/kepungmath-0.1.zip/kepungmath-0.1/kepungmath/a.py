def hello():
    print('hellllla')